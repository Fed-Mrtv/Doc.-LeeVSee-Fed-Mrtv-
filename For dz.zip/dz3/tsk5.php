<?php
\$car = [
    'brand' => 'Toyota',
    'model' => 'Camry'

];
print_r(\$car);